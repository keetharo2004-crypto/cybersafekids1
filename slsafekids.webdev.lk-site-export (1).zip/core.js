/**
 * CyberSafe Kids - Core Production Engine
 * Handles all state management, persistence, and game/lesson logic.
 */

const CyberSafeDB = {
    // Database Schema
    state: {
        user: {
            name: "Student",
            role: "student", // student, teacher, parent, admin
            level: 1,
            xp: 0,
            coins: 0,
            streak: 0,
            rank: "Cyber Explorer",
            lastLessonId: null
        },
        progress: {
            completedLessons: [], // Array of lesson IDs
            quizResults: {}, // { lessonId: score }
            badges: [], // Array of badge IDs
            certificates: [] // Array of lesson IDs
        },
        games: {
            highScores: {
                cybershield: 0
            }
        }
    },

    // Initialization
    init() {
        const savedState = localStorage.getItem('cybersafe_prod_data');
        if (savedState) {
            this.state = JSON.parse(savedState);
        }
        this.save();
    },

    save() {
        localStorage.setItem('cybersafe_prod_data', JSON.stringify(this.state));
    },

    // User Management
    setUser(userData) {
        this.state.user = { ...this.state.user, ...userData };
        this.save();
    },

    // Progression System
    addXP(amount) {
        this.state.user.xp += amount;
        this.checkLevelUp();
        this.save();
        return this.state.user.xp;
    },

    checkLevelUp() {
        const xpTable = [0, 500, 1200, 2000, 3000, 5000, 8000, 12000];
        const ranks = ["Cyber Explorer", "Digital Defender", "Network Guardian", "Security Expert", "Cyber Hero", "Elite Protector", "Master Shield", "Cyber Legend"];
        
        let newLevel = 1;
        for (let i = 0; i < xpTable.length; i++) {
            if (this.state.user.xp >= xpTable[i]) {
                newLevel = i + 1;
            }
        }
        
        if (newLevel !== this.state.user.level) {
            this.state.user.level = newLevel;
            this.state.user.rank = ranks[newLevel - 1] || ranks[ranks.length - 1];
        }
    },

    // Learning Management
    completeLesson(lessonId, score) {
        if (!this.state.progress.completedLessons.includes(lessonId)) {
            this.state.progress.completedLessons.push(lessonId);
            this.state.progress.certificates.push(lessonId);
            this.addXP(200);
            this.unlockBadge(lessonId);
        }
        this.state.progress.quizResults[lessonId] = score;
        this.state.user.lastLessonId = lessonId;
        this.save();
    },

    unlockBadge(lessonId) {
        const badgeMap = {
            'phishing': 'Scam Spotter',
            'sms': 'SMS Guardian',
            'whatsapp': 'Chat Defender',
            'passwords': 'Password Expert',
            'banking': 'Finance Protector',
            'social': 'Privacy Pro',
            'identity': 'ID Shield',
            'browsing': 'Safe Surfer'
        };
        const badge = badgeMap[lessonId];
        if (badge && !this.state.progress.badges.includes(badge)) {
            this.state.progress.badges.push(badge);
        }
    },

    // Game Integration
    saveGameScore(gameId, score) {
        if (score > this.state.games.highScores[gameId]) {
            this.state.games.highScores[gameId] = score;
        }
        // Award XP based on score (e.g., 1 XP per 10 points)
        this.addXP(Math.floor(score / 10));
        this.save();
    },

    // Utility
    getDashboardData() {
        return this.state.user;
    },

    getProgress() {
        return this.state.progress;
    }
};

// Initialize on load
window.addEventListener('DOMContentLoaded', () => {
    CyberSafeDB.init();
});
